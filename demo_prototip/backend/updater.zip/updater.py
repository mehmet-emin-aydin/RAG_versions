import time
import json
import requests
from dotenv import load_dotenv

#local objects
from client import ConfluenceClient
from space import Space


def update_given_spaces(spaces_keys : list = None):
    confluence_client = ConfluenceClient()
    print(spaces_keys)
    results = []
    for space_name in spaces_keys:
        space_instance = Space(confluence_client, space_name)
        result = space_instance.update_space()
        results.append(result)

    # with open('space_processing_results.json', 'w') as result_file:
    #     json.dump(results, result_file, indent=4)






# def main():
#     confluence_client = ConfluenceClient()
#     spaces_keys = ['YPZ', 'MYM', 'SPISS', 'YNYGAB']



# if __name__ == "__main__":
#     main()