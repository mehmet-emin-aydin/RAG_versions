




from langchain_community.embeddings import HuggingFaceEmbeddings

import pytesseract
pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract' 


import os
import time
import pandas as pd
import matplotlib.pyplot as plt
from dotenv import load_dotenv
import sys
sys.path.append('../..')

from llama_index.readers.confluence import ConfluenceReader


# .env dosyasından Confluence giriş bilgilerini yükle
load_dotenv()
confluence_username = os.getenv("CONFLUENCE_USERNAME")
confluence_password = os.getenv("CONFLUENCE_PASSWORD")

# Pytesseract ayarları
pytesseract.pytesseract.tesseract_cmd = '/usr/bin/tesseract' 

# Confluence ve model ayarları
base_url = "https://wiki.softtech.com.tr/"
space_keys = ["YNYGAB"]#, "YNYGAB", "SPISS"]
# space_keys = ["YPZ"]
reader = ConfluenceReader(base_url=base_url, user_name=confluence_username, password=confluence_password)
embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")

# Fonksiyon: Verilen işlemi süreyi ölçerek gerçekleştirir
def measure_time(func, *args, **kwargs):
    start_time = time.time()
    result = func(*args, **kwargs)
    print(len(result))
    end_time = time.time()
    elapsed_time = end_time - start_time
    return result, elapsed_time

# Sonuçları depolamak için dictionary
metrics = {}

# include_attachments=False için süreyi ölç
for space in space_keys:
    key = f'{space}_without_attachments'
    _, elapsed_time = measure_time(reader.load_data, include_attachments=False, space_key=space)
    metrics[key] = {'time_without_attachments': elapsed_time}

# include_attachments=True ve OCR kullanılmadan süreyi ölç
# for space in space_keys:
#     key = f'{space}_with_attachments_ocr_yes'
#     _, elapsed_time = measure_time(reader.load_data, include_attachments=True, space_key=space)
#     metrics[key] = {'time_with_attachments_ocr_yes': elapsed_time}

# # include_attachments=True ve OCR kullanılarak süreyi ölç
# for space in space_keys:
#     key = f'{space}_with_attachments_with_ocr'
#     original_ocr_function = reader.ocr_function  # Orijinal OCR fonksiyonunu kaydet
#     reader.ocr_function = lambda x: pytesseract.image_to_string(x)  # OCR fonksiyonunu ayarla
#     _, elapsed_time = measure_time(reader.load_data, include_attachments=True, space_key=space)
#     metrics[key] = {'time_with_attachments_with_ocr': elapsed_time}
#     reader.ocr_function = original_ocr_function  # Orijinal OCR fonksiyonunu geri yükle

# Sonuçları ekrana yazdır
for space, times in metrics.items():
    print(f"Space: {space}")
    for metric, time_taken in times.items():
        print(f"  {metric}: {time_taken:.2f} seconds")


# Sonuçları pandas DataFrame'e dönüştür
df = pd.DataFrame.from_dict(metrics, orient='index')

# Matplotlib ile tabloyu çiz ve kaydet
fig, ax = plt.subplots(figsize=(10, 6))  # Tablo boyutunu ayarlayabilirsiniz
ax.axis('tight')
ax.axis('off')
table = ax.table(cellText=df.values, colLabels=df.columns, rowLabels=df.index, cellLoc='center', loc='center')
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1.2, 1.2)  # Tablo boyutunu ölçekleyin

# Tabloyu görsel olarak kaydet
plt.savefig("confluence_metrics_table_YNYGAB.png", bbox_inches='tight', dpi=300)
plt.close()