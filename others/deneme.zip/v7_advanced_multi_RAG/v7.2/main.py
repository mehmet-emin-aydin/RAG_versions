import os
import io
import PyPDF2
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain.chains import ConversationalRetrievalChain
from langchain_openai import AzureChatOpenAI
from langchain.prompts import PromptTemplate
import streamlit as st
import docx
from langchain.load import dumps, loads
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_milvus import Milvus, Zilliz
from langchain_community.embeddings import HuggingFaceEmbeddings



from operator import itemgetter
from dotenv import load_dotenv
load_dotenv()
log_data = [] 
import sys
sys.path.append('../..')

azure_oai_key = os.getenv("AZURE_OPENAI_API_KEY")
azure_oai_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
api_version = "2024-02-15-preview"
llm_name = "gpt-4o"


# Streamlit sayfaları
def selectbox_page():
    st.title('Select Space')
    space_items = {
        "Ailab": "YPZ",
        "Mimari Yetkinlik Merkezi":"MYM",
        "Sermaye Piyasaları İşlem Sonrası Sistemleri Direktörlüğü": "SPISS" ,
    }
    # Koleksiyonları yükle
    space_names = list(space_items)
    spaces = [space_names[0], space_names[1], space_names[2]]  # Bu listeyi dinamik olarak doldurabilirsiniz.
    
    selected_space_name = st.selectbox('Select a space:', spaces)
    selected_space = space_items.get(selected_space_name)
    print(selected_space)
    if st.button('Go to Chatbot'):
        st.session_state.selected_space = selected_space
        st.session_state.page = 'chatbot'

def chatbot_page():
    st.title('Chatbot')
    
    if 'selected_space' not in st.session_state:
        st.error('No space selected. Please go back and select a space.')
        return
    
    selected_space = st.session_state.selected_space
    st.write(f'Selected Space: {selected_space}')


    
    # Chatbot girdisi
    user_query = st.text_input('Ask a question:')
    
    if st.button('Submit'):
        if user_query:
            embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
            vector_store= Milvus(
                embeddings,
                connection_args={"uri": "./milvus_demo.db"},
                collection_name=selected_space,
            )
            system_instruction = "Based on the context provided and chat history, answer the question as an easy-to-understand chat assistant. Ensure that the answer is concise, directly addresses the question, and is in the same language as the question."
            template = (
                f"{system_instruction} "
                "Combine the chat history and follow up question into "
                "a standalone question. Chat History: {{chat_history}}"
                "Follow up question: {{question}}"
            )
            condense_question_prompt = PromptTemplate.from_template(template)

            # ConversationalRetrievalChain 
            qa = ConversationalRetrievalChain.from_llm(
                llm=AzureChatOpenAI(model="gpt-4o", temperature=0, api_key=azure_oai_key, azure_endpoint=azure_oai_endpoint, api_version=api_version),
                retriever=vector_store.as_retriever(search_type="mmr", search_kwargs={"k": 5}),
                return_source_documents = True
                
            )
            response = qa.invoke({"question": user_query, "chat_history": ""})
            st.write('Answer:', response['answer'])
            st.write('Retrieved_chunks:',response['source_documents'])
        else:
            st.error('Please enter a question.')

# Sayfa yönlendirme
def main():
    if 'page' not in st.session_state:
        st.session_state.page = 'selectbox'
    
    if st.session_state.page == 'selectbox':
        selectbox_page()
    elif st.session_state.page == 'chatbot':
        chatbot_page()

if __name__ == '__main__':
    main()
