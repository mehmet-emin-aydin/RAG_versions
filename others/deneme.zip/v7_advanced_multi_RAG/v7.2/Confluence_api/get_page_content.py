import os
from dotenv import load_dotenv
import sys
import requests
from atlassian import Confluence 
import requests
import json
import time

load_dotenv()

# Confluence oturum bilgileri
confluence_username = os.getenv("CONFLUENCE_USERNAME")
confluence_password = os.getenv("CONFLUENCE_PASSWORD")

# confluence objesini oluşturma
confluence = Confluence(
    url="https://wiki.softtech.com.tr",
    username=confluence_username,
    password=confluence_password
)
page_id = 100012058
import json
import html2text
text_maker = html2text.HTML2Text()
text_maker.ignore_links = True
text_maker.ignore_images = True
page_content = confluence.get_page_by_id(page_id=page_id,expand="body.export_view.value")
text = text_maker.handle(page_content["body"]["export_view"]["value"])
                    
# from pprint import pprint
# json_content = json.dumps(page_content, indent =3)
print(text)






# import os
# from dotenv import load_dotenv
# import sys
# import requests
# from atlassian import Confluence 
# import requests
# import json
# import time
# load_dotenv()

# # Confluence oturum bilgileri
# confluence_username = os.getenv("CONFLUENCE_USERNAME")
# confluence_password = os.getenv("CONFLUENCE_PASSWORD")

# # confluence objesini oluşturma
# confluence = Confluence(
#     url="https://wiki.softtech.com.tr",
#     username=confluence_username,
#     password=confluence_password
# )
# # page_id = 100012058
# # import json
# # page_content = confluence.get_page_by_id(page_id=page_id)
# # from pprint import pprint
# # json_content = json.dumps(page_content, indent =3)
# # print(json_content)



# # Dosyadan veriyi yükleme (eski veriler), dosya yoksa veya boşsa boş bir liste döner
# def load_data_from_file(filename):
#     if os.path.exists(filename):
#         with open(filename, 'r') as file:
#             try:
#                 data = json.load(file)
#                 if isinstance(data, list):
#                     return data
#                 else:
#                     return []
#             except json.JSONDecodeError:
#                 return []
#     else:
#         return []

# # Güncellenmiş veriyi dosyaya yazma
# def save_data_to_file(filename, data):
#     with open(filename, 'w') as file:
#         json.dump(data, file, indent=4)

# # Değişiklikleri kontrol etme ve güncelleme fonksiyonu
# def update_when_values(old_data, new_data):
#     # Eski veriyi id'si ile tekrardan bir dict'e kaydedelim ki value comparison hızlı olsun
#     old_data_dict = {item['id']: item for item in old_data}
#     changed_ids = []
#     # Yeni datadaki id eskide varsa when'leri kıyasla, yoksa yeni item diye ekle
#     for new_item in new_data:
#         new_id = new_item['id']
#         new_when = new_item['when']
#         # Eski datadaysa ve when'i değiştiyse bilgileri güncellediğimiz kısım
#         if new_id in old_data_dict:
#             if old_data_dict[new_id]['when'] != new_when:
#                 old_data_dict[new_id]['when'] = new_when
#                 changed_ids.append(new_id)
#         else:
#             # Eski datada bu id yoksa yeni item olarak ekle
#             old_data_dict[new_id] = new_item
#             changed_ids.append(new_id)
#     return list(old_data_dict.values()), changed_ids

# # Attachment'ları indirme fonksiyonu
# def upload_attachments(space, page_id):
#     # Sayfadaki ekleri çekme
#     attachments_container = confluence.get_attachments_from_content(page_id=page_id, start=0, limit=500)
#     attachments = attachments_container['results']
#     total_size = 0
#     if attachments:
#         # Sayfa adıyla klasör oluştur
#         directory_name = os.path.join(space, str(page_id))
#         if not os.path.exists(directory_name):
#             os.makedirs(directory_name)
#         # Ekleri klasöre kaydetme
#         for attachment in attachments:
#             fname = attachment['title']
#             download_link = confluence.url + attachment['_links']['download']
#             att_type = attachment["metadata"]["mediaType"]
#             if att_type not in ['video/mp4', 'audio/mp4', "application/octet-stream"]:
#                 print(f'{page_id} {att_type}')
#                 r = requests.get(download_link, auth=(confluence.username, confluence_password))
#                 if r.status_code == 200:
#                     file_path = os.path.join(directory_name, fname)
#                     with open(file_path, "wb") as f:
#                         for bits in r.iter_content():
#                             f.write(bits)
#                         total_size += os.path.getsize(file_path)
#     return total_size

# # Space'leri işleyen fonksiyon
# def process_spaces(spaces):
#     results = []
#     for space in spaces:
#         space_start_time = time.time()
#         space_size = 0

#         # Space için klasör oluşturma
#         if not os.path.exists(space):
#             os.makedirs(space)

#         # Spaceteki yüklü pagelerin id'lerini alalım
#         file_name = 'page_ids.json'
#         file_name = os.path.join(space, file_name)
#         old_data = load_data_from_file(file_name)
#         # space_container = []
#         # # Yeni id'ler için spaceteki tüm pagelerin id'lerini alma
#         # start = 0
#         # limit = 50
#         # max_num_results = 1000
#         # max_num_remaining = max_num_results
#         # while True:
#         #     print("start" + str(start))
#         #     results = confluence.get_all_pages_from_space_raw(space=space, start=start, limit=limit)
#         #     space_container.extend(results['results'])
#         #     if ( len(results['results']) == 0 or max_num_results is not None and len(results['results'])>= max_num_remaining ):
#         #         break
#         #     start += limit

#         #     if max_num_remaining is not None:
#         #         max_num_remaining -= limit
#         # space_container = []
#         # result = confluence.get_all_pages_from_space_raw(space=space, start=0, limit=50)
#         # space_container.extend(result['results'])
#         # result = confluence.get_all_pages_from_space_raw(space=space, start=50, limit=50)
#         # space_container.extend(result['results'])
#         # Yeni id'ler için spaceteki tüm pagelerin id'lerini alma
#         space_container = []
#         space_container += confluence.get_all_pages_from_space_raw(space=space, start=0, limit=50)['results']
#         space_container += confluence.get_all_pages_from_space_raw(space=space, start=0, limit=50)['results']
#         print(len(space_container))
#         new_data = []
#         for page in space_container:
#             page_id = page['id']
#             # Page_id ile version attribute'ünü alma
#             page_details = confluence.get_page_by_id(page_id=page_id)
#             when_value = page_details['version']['when']
#             new_data.append({'id': page_id, 'when': when_value})

#         # Değişen when'leri güncelle ve değişen pagelerin id'lerini al
#         updated_data, changed_ids = update_when_values(old_data, new_data)

#         # Page bilgilerini güncelleme
#         save_data_to_file(file_name, updated_data)

#         # Değişen veya eklenen sayfaların eklerini güncelleme ve boyutunu hesaplama
#         for page_id in changed_ids:
#             print(f'Downloading attachments for page_id: {page_id} in space: {space}')
#             space_size += upload_attachments(space, page_id)

#         space_duration = time.time() - space_start_time
#         results.append({
#             'space': space,
#             'total_size_mb': space_size / (1024 * 1024),
#             'duration_seconds': space_duration
#         })
    
#     # # Sonuçları dosyaya yazma
#     # with open('space_processing_results_1.json', 'w') as result_file:
#     #     json.dump(results, result_file, indent=4)

# # İşlenecek space'lerin listesi
# spaces_to_process = ['SVUY']  

# # Space'leri işle
# process_spaces(spaces_to_process)























#1. get page ids from get_all_pages_from_space()
#2. get version attribute of pages by get_page_by_id




# from atlassian.rest_client import AtlassianRestAPI


# params = {}

# params['spaceKey'] = "MYM"
# params['start'] = 0
# params['limit'] = 50
# params['type'] = "page"
# url = 'rest/api/content'
# api = AtlassianRestAPI(
#     url="https://wiki.softtech.com.tr",
#     username=confluence_username,
#     password=confluence_password
# )
# response = api.get(url, params)
# for i in response['results']:
#     print(i['id'])

















#1. get page ids from get_all_pages_from_space()
#2. get version attribute of pages by get_page_by_id




# from atlassian.rest_client import AtlassianRestAPI


# params = {}

# params['spaceKey'] = "MYM"
# params['start'] = 0
# params['limit'] = 50
# params['type'] = "page"
# url = 'rest/api/content'
# api = AtlassianRestAPI(
#     url="https://wiki.softtech.com.tr",
#     username=confluence_username,
#     password=confluence_password
# )
# response = api.get(url, params)
# for i in response['results']:
#     print(i['id'])