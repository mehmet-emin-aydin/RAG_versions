import streamlit as st

# Ana sayfa ve seçim işlemi
def homepage():
    st.title("Select a Space")

    # Kullanıcı ana sayfaya döndüğünde oturumu sıfırlıyoruz
    if "selected_space" not in st.session_state:
        st.session_state.selected_space = None

    space_items = {
        "Ailab": "YPZ",
        "Mimari Yetkinlik Merkezi": "MYM",
        "Sermaye Piyasaları İşlem Sonrası Sistemleri Direktörlüğü": "SPISS",
    }

    space_names = list(space_items.keys())
    selected_space_name = st.selectbox('Select a space:', space_names)

    if selected_space_name:
        st.session_state.selected_space = space_items.get(selected_space_name)

    # Butona basıldığında sayfa yönlendirmesi yapılır
    if st.button('Select'):
        if st.session_state.selected_space:
            st.session_state.page = 'ChatbotPage'
            st.rerun()

if __name__ == "__main__":
    homepage()
