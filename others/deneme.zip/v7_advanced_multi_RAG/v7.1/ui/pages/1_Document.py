import streamlit as st


st.title("Projects")

st.write("You have entered", st.session_state["my_input"])